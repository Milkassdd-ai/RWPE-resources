<?php

namespace zhmurkov\loaders;

use customiesdevs\customies\block\CustomiesBlockFactory;
use customiesdevs\customies\block\Material;
use customiesdevs\customies\block\Model;
use customiesdevs\customies\item\CreativeInventoryInfo;
use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockIdentifier;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\BlockTypeInfo;
use pocketmine\math\Vector3;
use zhmurkov\block\RotatableBlock;

class RegisterWindows
{
    public static function load()
    {
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "Okno1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:okno_1",
            new Model([new Material(Material::TARGET_ALL, "okno_1", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.okno_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "Okno2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:okno_2",
            new Model([new Material(Material::TARGET_ALL, "okno_2", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.okno_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "Okno3", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:okno_3",
            new Model([new Material(Material::TARGET_ALL, "okno_3", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.okno_3", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "okno2_0", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:okno_2_0",
            new Model([new Material(Material::TARGET_ALL, "okno_2_0", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.okno_2_0", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "okno_2_3", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:okno_2_3",
            new Model([new Material(Material::TARGET_ALL, "okno_2_3", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.okno_2_3", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

    }
}