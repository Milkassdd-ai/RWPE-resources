<?php

namespace zhmurkov\loaders;

use customiesdevs\customies\block\CustomiesBlockFactory;
use customiesdevs\customies\block\Material;
use customiesdevs\customies\block\Model;
use customiesdevs\customies\item\CreativeInventoryInfo;
use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockIdentifier;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\BlockTypeInfo;
use pocketmine\math\Vector3;
use zhmurkov\block\RotatableBlock;

class RegisterRail
{
    public static function load()
    {
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "Rail1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:rail_1",
            new Model([new Material(Material::TARGET_ALL, "rail_1", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.rail_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "Rail2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:rail_2",
            new Model([new Material(Material::TARGET_ALL, "rail_2", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.rail_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "Rail3", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:rail_3",
            new Model([new Material(Material::TARGET_ALL, "rail_3", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.rail_3", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "Rail4", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:rail_4",
            new Model([new Material(Material::TARGET_ALL, "rail_4", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.rail_4", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "Rail5", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:rail_5",
            new Model([new Material(Material::TARGET_ALL, "rail_5", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.rail_5", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "Rail6", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:rail_6",
            new Model([new Material(Material::TARGET_ALL, "rail_6", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.rail_6", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "Rail7", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:rail_7",
            new Model([new Material(Material::TARGET_ALL, "rail_7", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.rail_7", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
    }
}