<?php

namespace zhmurkov\loaders;

use customiesdevs\customies\block\CustomiesBlockFactory;
use customiesdevs\customies\block\Material;
use customiesdevs\customies\block\Model;
use customiesdevs\customies\item\CreativeInventoryInfo;
use pocketmine\block\Block;
use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockIdentifier;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\BlockTypeInfo;
use pocketmine\math\Vector3;
use zhmurkov\block\RotatableBlock;

class RegisterUtils
{
    public static function load()
    {
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "lampa_podyezd", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:lampa_podyezd",
            new Model([new Material(Material::TARGET_ALL, "lampa_podyezd", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.lampa_podyezd", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "sosulka_1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:sosulka_1",
            new Model([new Material(Material::TARGET_ALL, "sosulka_1", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.sosulka_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "sosulka_2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:sosulka_2",
            new Model([new Material(Material::TARGET_ALL, "sosulka_2", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.sosulka_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "lavka_1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:lavka_1",
            new Model([new Material(Material::TARGET_ALL, "lavka_1", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.lavka_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "lavka_2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:lavka_2",
            new Model([new Material(Material::TARGET_ALL, "lavka_2", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.lavka_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "lavka_3", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:lavka_3",
            new Model([new Material(Material::TARGET_ALL, "lavka_3", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.lavka_3", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "konder_1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:konder_1",
            new Model([new Material(Material::TARGET_ALL, "konder_1", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.konder_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "flag_1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:flag_1",
            new Model([new Material(Material::TARGET_ALL, "flag_1", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.flag_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "flag_2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:flag_2",
            new Model([new Material(Material::TARGET_ALL, "flag_2", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.flag_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "otboynik_1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:otboynik_1",
            new Model([new Material(Material::TARGET_ALL, "otboynik_1", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.otboynik_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "konus_1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:konus_1",
            new Model([new Material(Material::TARGET_ALL, "konus_1", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.konus_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "ugol_up_1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:ugol_up_1",
            new Model([new Material(Material::TARGET_ALL, "ugol_up_1", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.ugol_up_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "ugol_up_2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:ugol_up_2",
            new Model([new Material(Material::TARGET_ALL, "ugol_up_2", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.ugol_up_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "ugol_down_1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:ugol_down_1",
            new Model([new Material(Material::TARGET_ALL, "ugol_down_1", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.ugol_down_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "ugol_down_2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:ugol_down_2",
            new Model([new Material(Material::TARGET_ALL, "ugol_down_2", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.ugol_down_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "planka_up", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:planka_up",
            new Model([new Material(Material::TARGET_ALL, "planka_up", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.planka_up", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "planka_down", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:planka_down",
            new Model([new Material(Material::TARGET_ALL, "planka_down", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.planka_down", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "krisha", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:krisha",
            new Model([new Material(Material::TARGET_ALL, "krisha", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.krisha", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "full_pol", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:full_pol",
            new Model([new Material(Material::TARGET_ALL, "full_pol", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.full_pol", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "planka_up_2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:planka_up_2",
            new Model([new Material(Material::TARGET_ALL, "planka_up_2", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.planka_up_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "planka_up_3", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:planka_up_3",
            new Model([new Material(Material::TARGET_ALL, "planka_up_3", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.planka_up_3", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "planka_down_2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:planka_down_2",
            new Model([new Material(Material::TARGET_ALL, "planka_down_2", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.planka_down_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
    }
}