<?php

namespace zhmurkov\loaders;

use customiesdevs\customies\block\CustomiesBlockFactory;
use customiesdevs\customies\block\Material;
use customiesdevs\customies\block\Model;
use customiesdevs\customies\item\CreativeInventoryInfo;
use pocketmine\block\Block;
use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockIdentifier;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\BlockTypeInfo;
use pocketmine\math\Vector3;
use zhmurkov\block\RotatableBlock;

class RegisterWallbricks
{
    public static function load()
    {
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallbrick1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallbrick1",
            new Model([new Material(Material::TARGET_ALL, "wallbrick1", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallbrick2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallbrick2",
            new Model([new Material(Material::TARGET_ALL, "wallbrick2", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallbrick3", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallbrick3",
            new Model([new Material(Material::TARGET_ALL, "wallbrick3", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallbrick4", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallbrick4",
            new Model([new Material(Material::TARGET_ALL, "wallbrick4", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallbrick5", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallbrick5",
            new Model([new Material(Material::TARGET_ALL, "wallbrick5", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallbrick6", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallbrick6",
            new Model([new Material(Material::TARGET_ALL, "wallbrick6", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallbrick7", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallbrick7",
            new Model([new Material(Material::TARGET_ALL, "wallbrick7", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallbrick8", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallbrick8",
            new Model([new Material(Material::TARGET_ALL, "wallbrick8", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallbrick9", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallbrick9",
            new Model([new Material(Material::TARGET_ALL, "wallbrick9", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallbrick10", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallbrick10",
            new Model([new Material(Material::TARGET_ALL, "wallbrick10", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallbrick11", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallbrick11",
            new Model([new Material(Material::TARGET_ALL, "wallbrick11", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallbrick12", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallbrick12",
            new Model([new Material(Material::TARGET_ALL, "wallbrick12", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallbrick13", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallbrick13",
            new Model([new Material(Material::TARGET_ALL, "wallbrick13", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
    }
}