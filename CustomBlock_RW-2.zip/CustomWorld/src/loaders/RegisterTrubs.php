<?php

namespace zhmurkov\loaders;

use customiesdevs\customies\block\CustomiesBlockFactory;
use customiesdevs\customies\block\Material;
use customiesdevs\customies\block\Model;
use customiesdevs\customies\item\CreativeInventoryInfo;
use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockIdentifier;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\BlockTypeInfo;
use pocketmine\math\Vector3;
use zhmurkov\block\RotatableBlock;

class RegisterTrubs
{
    public static function load()
    {
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_1_yellow", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_1_yellow",
            new Model([new Material(Material::TARGET_ALL, "truba_1_yellow", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_2_yellow", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_2_yellow",
            new Model([new Material(Material::TARGET_ALL, "truba_2_yellow", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_3_yellow", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_3_yellow",
            new Model([new Material(Material::TARGET_ALL, "truba_3_yellow", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_3", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_4_yellow", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_4_yellow",
            new Model([new Material(Material::TARGET_ALL, "truba_4_yellow", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_4", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_5_yellow", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_5_yellow",
            new Model([new Material(Material::TARGET_ALL, "truba_5_yellow", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_5", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_6_yellow", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_6_yellow",
            new Model([new Material(Material::TARGET_ALL, "truba_6_yellow", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_6", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_7_yellow", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_7_yellow",
            new Model([new Material(Material::TARGET_ALL, "truba_7_yellow", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_7", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_8_yellow", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_8_yellow",
            new Model([new Material(Material::TARGET_ALL, "truba_8_yellow", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_8", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_9_yellow", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_9_yellow",
            new Model([new Material(Material::TARGET_ALL, "truba_9_yellow", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_9", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_10_yellow", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_10_yellow",
            new Model([new Material(Material::TARGET_ALL, "truba_10_yellow", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_10", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_11_yellow", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_11_yellow",
            new Model([new Material(Material::TARGET_ALL, "truba_11_yellow", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_11", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_12_yellow", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_12_yellow",
            new Model([new Material(Material::TARGET_ALL, "truba_12_yellow", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_12", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_13_yellow", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_13_yellow",
            new Model([new Material(Material::TARGET_ALL, "truba_13_yellow", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_13", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_14_yellow", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_14_yellow",
            new Model([new Material(Material::TARGET_ALL, "truba_14_yellow", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_14", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_15_yellow", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_15_yellow",
            new Model([new Material(Material::TARGET_ALL, "truba_15_yellow", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_15", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_16_yellow", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_16_yellow",
            new Model([new Material(Material::TARGET_ALL, "truba_16_yellow", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_16", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_17_yellow", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_17_yellow",
            new Model([new Material(Material::TARGET_ALL, "truba_17_yellow", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_17", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_18_yellow", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_18_yellow",
            new Model([new Material(Material::TARGET_ALL, "truba_18_yellow", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_18", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_19_yellow", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_19_yellow",
            new Model([new Material(Material::TARGET_ALL, "truba_19_yellow", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_19", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_20_yellow", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_20_yellow",
            new Model([new Material(Material::TARGET_ALL, "truba_20_yellow", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_20", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_21_yellow", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_21_yellow",
            new Model([new Material(Material::TARGET_ALL, "truba_21_yellow", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_21", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_22_yellow", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_22_yellow",
            new Model([new Material(Material::TARGET_ALL, "truba_22_yellow", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_22", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_23_yellow", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_23_yellow",
            new Model([new Material(Material::TARGET_ALL, "truba_23_yellow", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_23", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_24_yellow", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_24_yellow",
            new Model([new Material(Material::TARGET_ALL, "truba_24_yellow", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_24", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_1_grey", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_1_grey",
            new Model([new Material(Material::TARGET_ALL, "truba_1_grey", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_2_grey", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_2_grey",
            new Model([new Material(Material::TARGET_ALL, "truba_2_grey", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_3_grey", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_3_grey",
            new Model([new Material(Material::TARGET_ALL, "truba_3_grey", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_3", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_4_grey", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_4_grey",
            new Model([new Material(Material::TARGET_ALL, "truba_4_grey", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_4", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_5_grey", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_5_grey",
            new Model([new Material(Material::TARGET_ALL, "truba_5_grey", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_5", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_6_grey", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_6_grey",
            new Model([new Material(Material::TARGET_ALL, "truba_6_grey", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_6", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_7_grey", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_7_grey",
            new Model([new Material(Material::TARGET_ALL, "truba_7_grey", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_7", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_8_grey", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_8_grey",
            new Model([new Material(Material::TARGET_ALL, "truba_8_grey", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_8", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_9_grey", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_9_grey",
            new Model([new Material(Material::TARGET_ALL, "truba_9_grey", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_9", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_10_grey", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_10_grey",
            new Model([new Material(Material::TARGET_ALL, "truba_10_grey", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_10", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_11_grey", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_11_grey",
            new Model([new Material(Material::TARGET_ALL, "truba_11_grey", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_11", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_12_grey", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_12_grey",
            new Model([new Material(Material::TARGET_ALL, "truba_12_grey", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_12", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_13_grey", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_13_grey",
            new Model([new Material(Material::TARGET_ALL, "truba_13_grey", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_13", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_14_grey", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_14_grey",
            new Model([new Material(Material::TARGET_ALL, "truba_14_grey", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_14", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_15_grey", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_15_grey",
            new Model([new Material(Material::TARGET_ALL, "truba_15_grey", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_15", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_16_grey", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_16_grey",
            new Model([new Material(Material::TARGET_ALL, "truba_16_grey", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_16", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_17_grey", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_17_grey",
            new Model([new Material(Material::TARGET_ALL, "truba_17_grey", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_17", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_18_grey", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_18_grey",
            new Model([new Material(Material::TARGET_ALL, "truba_18_grey", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_18", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_19_grey", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_19_grey",
            new Model([new Material(Material::TARGET_ALL, "truba_19_grey", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_19", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_20_grey", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_20_grey",
            new Model([new Material(Material::TARGET_ALL, "truba_20_grey", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_20", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_21_grey", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_21_grey",
            new Model([new Material(Material::TARGET_ALL, "truba_21_grey", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_21", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_22_grey", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_22_grey",
            new Model([new Material(Material::TARGET_ALL, "truba_22_grey", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_22", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_23_grey", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_23_grey",
            new Model([new Material(Material::TARGET_ALL, "truba_23_grey", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_23", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_24_grey", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_24_grey",
            new Model([new Material(Material::TARGET_ALL, "truba_24_grey", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_24", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_1_rusty", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_1_rusty",
            new Model([new Material(Material::TARGET_ALL, "truba_1_rusty", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_2_rusty", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_2_rusty",
            new Model([new Material(Material::TARGET_ALL, "truba_2_rusty", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_3_rusty", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_3_rusty",
            new Model([new Material(Material::TARGET_ALL, "truba_3_rusty", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_3", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_4_rusty", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_4_rusty",
            new Model([new Material(Material::TARGET_ALL, "truba_4_rusty", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_4", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_5_rusty", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_5_rusty",
            new Model([new Material(Material::TARGET_ALL, "truba_5_rusty", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_5", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_6_rusty", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_6_rusty",
            new Model([new Material(Material::TARGET_ALL, "truba_6_rusty", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_6", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_7_rusty", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_7_rusty",
            new Model([new Material(Material::TARGET_ALL, "truba_7_rusty", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_7", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_8_rusty", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_8_rusty",
            new Model([new Material(Material::TARGET_ALL, "truba_8_rusty", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_8", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_9_rusty", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_9_rusty",
            new Model([new Material(Material::TARGET_ALL, "truba_9_rusty", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_9", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_10_rusty", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_10_rusty",
            new Model([new Material(Material::TARGET_ALL, "truba_10_rusty", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_10", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_11_rusty", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_11_rusty",
            new Model([new Material(Material::TARGET_ALL, "truba_11_rusty", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_11", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_12_rusty", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_12_rusty",
            new Model([new Material(Material::TARGET_ALL, "truba_12_rusty", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_12", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_13_rusty", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_13_rusty",
            new Model([new Material(Material::TARGET_ALL, "truba_13_rusty", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_13", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_14_rusty", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_14_rusty",
            new Model([new Material(Material::TARGET_ALL, "truba_14_rusty", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_14", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_15_rusty", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_15_rusty",
            new Model([new Material(Material::TARGET_ALL, "truba_15_rusty", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_15", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_16_rusty", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_16_rusty",
            new Model([new Material(Material::TARGET_ALL, "truba_16_rusty", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_16", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_17_rusty", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_17_rusty",
            new Model([new Material(Material::TARGET_ALL, "truba_17_rusty", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_17", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_18_rusty", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_18_rusty",
            new Model([new Material(Material::TARGET_ALL, "truba_18_rusty", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_18", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_19_rusty", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_19_rusty",
            new Model([new Material(Material::TARGET_ALL, "truba_19_rusty", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_19", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_20_rusty", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_20_rusty",
            new Model([new Material(Material::TARGET_ALL, "truba_20_rusty", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_20", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_21_rusty", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_21_rusty",
            new Model([new Material(Material::TARGET_ALL, "truba_21_rusty", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_21", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_22_rusty", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_22_rusty",
            new Model([new Material(Material::TARGET_ALL, "truba_22_rusty", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_22", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_23_rusty", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_23_rusty",
            new Model([new Material(Material::TARGET_ALL, "truba_23_rusty", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_23", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "truba_24_rusty", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:truba_24_rusty",
            new Model([new Material(Material::TARGET_ALL, "truba_24_rusty", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.truba_24", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
    }
}