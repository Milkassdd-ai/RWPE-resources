<?php

namespace zhmurkov\loaders;

use customiesdevs\customies\block\CustomiesBlockFactory;
use customiesdevs\customies\block\Material;
use customiesdevs\customies\block\Model;
use customiesdevs\customies\item\CreativeInventoryInfo;
use pocketmine\block\Block;
use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockIdentifier;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\BlockTypeInfo;
use pocketmine\math\Vector3;
use zhmurkov\block\RotatableBlock;

class RegisterPanels
{
    public static function load()
    {
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "rozovaya_panel", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:rozovaya_panel",
            new Model([new Material(Material::TARGET_ALL, "rozovaya_panel", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "rozovaya_panel_1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:rozovaya_panel_1",
            new Model([new Material(Material::TARGET_ALL, "rozovaya_panel_1", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "rozovaya_panel_2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:rozovaya_panel_2",
            new Model([new Material(Material::TARGET_ALL, "rozovaya_panel_2", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "rozovaya_panel_3", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:rozovaya_panel_3",
            new Model([new Material(Material::TARGET_ALL, "rozovaya_panel_3", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "rozovaya_panel_4", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:rozovaya_panel_4",
            new Model([new Material(Material::TARGET_ALL, "rozovaya_panel_4", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "rozovaya_panel_5", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:rozovaya_panel_5",
            new Model([new Material(Material::TARGET_ALL, "rozovaya_panel_5", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "rozovaya_panel_6", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:rozovaya_panel_6",
            new Model([new Material(Material::TARGET_ALL, "rozovaya_panel_6", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "rozovaya_panel_7", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:rozovaya_panel_7",
            new Model([new Material(Material::TARGET_ALL, "rozovaya_panel_7", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "seraya_panel", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:seraya_panel",
            new Model([new Material(Material::TARGET_ALL, "seraya_panel", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "seraya_panel_1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:seraya_panel_1",
            new Model([new Material(Material::TARGET_ALL, "seraya_panel_1", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "seraya_panel_2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:seraya_panel_2",
            new Model([new Material(Material::TARGET_ALL, "seraya_panel_2", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "seraya_panel_2_1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:seraya_panel_2_1",
            new Model([new Material(Material::TARGET_ALL, "seraya_panel_2_1", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "seraya_panel_3", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:seraya_panel_3",
            new Model([new Material(Material::TARGET_ALL, "seraya_panel_3", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "seraya_panel_3_1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:seraya_panel_3_1",
            new Model([new Material(Material::TARGET_ALL, "seraya_panel_3_1", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "seraya_panel_4", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:seraya_panel_4",
            new Model([new Material(Material::TARGET_ALL, "seraya_panel_4", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "seraya_panel_4_1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:seraya_panel_4_1",
            new Model([new Material(Material::TARGET_ALL, "seraya_panel_4_1", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "seraya_panel_5", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:seraya_panel_5",
            new Model([new Material(Material::TARGET_ALL, "seraya_panel_5", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "seraya_panel_6", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:seraya_panel_6",
            new Model([new Material(Material::TARGET_ALL, "seraya_panel_6", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "seraya_panel_7", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:seraya_panel_7",
            new Model([new Material(Material::TARGET_ALL, "seraya_panel_7", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "seraya_panel_7_1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:seraya_panel_7_1",
            new Model([new Material(Material::TARGET_ALL, "seraya_panel_7_1", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "seraya_panel_8", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:seraya_panel_8",
            new Model([new Material(Material::TARGET_ALL, "seraya_panel_8", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "seraya_panel_9", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:seraya_panel_9",
            new Model([new Material(Material::TARGET_ALL, "seraya_panel_9", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "seraya_panel_10", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:seraya_panel_10",
            new Model([new Material(Material::TARGET_ALL, "seraya_panel_10", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "seraya_panel_11", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:seraya_panel_11",
            new Model([new Material(Material::TARGET_ALL, "seraya_panel_11", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "seraya_panel_11_1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:seraya_panel_11_1",
            new Model([new Material(Material::TARGET_ALL, "seraya_panel_11_1", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "seraya_panel_12", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:seraya_panel_12",
            new Model([new Material(Material::TARGET_ALL, "seraya_panel_12", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "seraya_panel_12_1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:seraya_panel_12_1",
            new Model([new Material(Material::TARGET_ALL, "seraya_panel_12_1", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "seraya_panel_13", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:seraya_panel_13",
            new Model([new Material(Material::TARGET_ALL, "seraya_panel_13", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "seraya_panel_14", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:seraya_panel_14",
            new Model([new Material(Material::TARGET_ALL, "seraya_panel_14", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "seraya_panel_15", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:seraya_panel_15",
            new Model([new Material(Material::TARGET_ALL, "seraya_panel_15", Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
    }
}