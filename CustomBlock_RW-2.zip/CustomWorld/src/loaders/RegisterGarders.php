<?php

namespace zhmurkov\loaders;

use customiesdevs\customies\block\CustomiesBlockFactory;
use customiesdevs\customies\block\Material;
use customiesdevs\customies\block\Model;
use customiesdevs\customies\item\CreativeInventoryInfo;
use pocketmine\block\Block;
use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockIdentifier;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\BlockTypeInfo;
use pocketmine\math\Vector3;
use zhmurkov\block\RotatableBlock;

class RegisterGarders
{
    public static function load()
    {
        $id = BlockTypeIds::newId();
        $name = "garaz_center_left_blue";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_center_left_green";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_no_dver", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_center_left_rjav";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_no_dver", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_center_right_blue";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_no_dver", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_center_right_green";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_no_dver", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_center_right_rjav";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_no_dver", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_down_left_blue";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_down_dver_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_down_left_green";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_down_dver_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_down_left_rjav";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_down_dver_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_down_right_blue";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_down_dver_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_down_right_green";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_down_dver_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_down_right_rjav";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_down_dver_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_up_left_blue";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_up_dver_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_up_left_green";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_up_dver_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_up_left_rjav";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_up_dver_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_up_right_blue";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_up_dver_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_up_right_green";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_up_dver_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_up_right_rjav";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_up_dver_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_1_down_dver_blue";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_down_dver_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_1_down_dver_green";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_down_dver_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_1_down_dver_rjav";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_down_dver_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_2_down_dver_blue";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_down_dver_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_2_down_dver_green";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_down_dver_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_2_down_dver_rjav";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_down_dver_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_1_up_dver_blue";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_up_dver_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_1_up_dver_green";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_up_dver_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_1_up_dver_rjav";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_up_dver_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_2_up_dver_blue";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_up_dver_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_2_up_dver_green";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_up_dver_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garaz_2_up_dver_rjav";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.garaz_up_dver_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "yasas_305";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "shifer_1";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "shkaf_1";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "shkaf_2";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "shkaf_3";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "stolb_3";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "stolb_4";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "stolb_5";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        $name = "garder1";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garder2";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garder3";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garder4";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garder5";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garder6";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garder7";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garder8";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garder9";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garder10";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garder11";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garder12";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garder13";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garder14";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garder15";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garder16";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "garder17";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "komp";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "kover1";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "kover2";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "lampa";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "microvolnovka";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "cabinet1";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "cabinet2";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "cabinet3";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "cabinet3_low";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "cabinet4";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "cabinet5";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "cabinet6";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "cabinet7";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "cabinet8";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "cabinet9";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "telephone";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "tv";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "vidik";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "vlad1";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "vlad2";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "vlad3";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "stair";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "aragaz";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "mognitofon";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "musorka";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "mail";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "gazvoda";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "fridge";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "divan";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "browndoor";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "whitedoor";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "telik";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "stoltv";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "shkaf";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "shchitok3";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "shchitok2";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "shchitok1";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "servantik";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "radio";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "pirila";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        $name = "kartina_1";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "kartina_2";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "kartina_3";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "kartina_4";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "kartina_5";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "kartina_6";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "kartina_7";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "kartina_8";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        $name = "stenka_1";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "stenka_2";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "stenka_3";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "stenka_4";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "stenka_5";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "stenka_6";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "stenka_7";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "stenka_8";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "stenka_9";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "stenka_10";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "stenka_11";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)], "geometry.$name", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        $name = "krasny_mramor_pol_1";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "krasny_mramor_pol_2";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "krasny_mramor_pol_3";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "krasny_mramor_pol_4";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "krasny_mramor_pol_5";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        $name = "rozovaya_khruscha_1_2";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "rozovaya_khruscha_2_1";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "rozovaya_khruscha_3_1";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "rozovaya_khruscha_4_1";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "rozovaya_khruscha2_1";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "rozovaya_khruscha2_2";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "rozovaya_khruscha2_3";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "rozovaya_khruscha2_4";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "rozovaya_khruscha2_5";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "rozovaya_khruscha2_6";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        $name = "zelyonaya_khruscha_1";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "zelyonaya_khruscha_2";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "zelyonaya_khruscha_3";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "zelyonaya_khruscha_4";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "zelyonaya_khruscha_5";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "zelyonaya_khruscha_6";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "zhyoltaya_khruscha";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "zhyoltaya_khruscha_1";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "zhyoltaya_khruscha_2";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "zhyoltaya_khruscha_3";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "zhyoltaya_khruscha_4";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "zhyoltaya_khruscha_5";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "zhyoltaya_khruscha_6";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "zhyoltaya_khruscha_7";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "zhyoltaya_khruscha_8";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "zhyoltaya_khruscha_9";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "zhyoltaya_khruscha_10";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "zhyoltaya_khruscha2_1";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "zhyoltaya_khruscha2_2";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "zhyoltaya_khruscha2_3";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "zhyoltaya_khruscha2_4";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "zhyoltaya_khruscha2_5";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        $name = "zhyoltaya_khruscha2_6";
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), $name, new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:$name",
            new Model([new Material(Material::TARGET_ALL, $name, Material::RENDER_METHOD_ALPHA_TEST)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
    }
}