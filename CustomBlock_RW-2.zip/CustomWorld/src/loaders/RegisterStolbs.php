<?php

namespace zhmurkov\loaders;

use customiesdevs\customies\block\CustomiesBlockFactory;
use customiesdevs\customies\block\Material;
use customiesdevs\customies\block\Model;
use customiesdevs\customies\item\CreativeInventoryInfo;
use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockIdentifier;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\BlockTypeInfo;
use pocketmine\math\Vector3;
use zhmurkov\block\RotatableBlock;

class RegisterStolbs
{
    public static function load()
    {
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_1",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_1", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_2",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_2", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_3", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_3",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_3", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_3", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_4", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_4",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_4", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_4", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_5", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_5",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_5", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_5", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_6", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_6",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_6", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_6", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_7", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_7",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_7", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_7", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_8", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_8",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_8", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_8", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_9", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_9",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_9", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_9", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_10", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_10",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_10", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_10", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_11", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_11",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_11", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_11", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_12", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_12",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_12", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_12", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_13", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_13",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_13", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_13", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_14", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_14",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_14", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_14", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_15", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_15",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_15", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_15", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_16", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_16",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_16", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_16", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_17", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_17",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_17", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_17", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_18", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_18",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_18", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_18", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_19", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_19",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_19", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_19", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_20", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_20",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_20", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_20", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_21", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_21",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_21", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_21", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_22", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_22",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_22", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_22", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_23", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_23",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_23", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_23", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_24", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_24",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_24", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_24", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_25", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_25",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_25", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_25", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_26", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_26",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_26", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_26", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_27", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_27",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_27", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_27", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_28", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_28",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_28", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_28", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_29", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_29",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_29", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_29", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_30", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_30",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_30", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_30", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_31", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_31",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_31", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_31", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_32", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_32",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_32", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_32", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_33", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_33",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_33", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_33", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_34", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_34",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_34", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_34", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_35", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_35",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_35", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_35", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_36", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_36",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_36", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_36", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_37", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_37",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_37", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_37", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "fonar_stolb_osnova", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:fonar_stolb_osnova",
            new Model([new Material(Material::TARGET_ALL, "fonar_stolb_osnova", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.fonar_stolb_osnova", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
    }
}