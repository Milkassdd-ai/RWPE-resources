<?php

namespace zhmurkov\loaders;

use customiesdevs\customies\block\CustomiesBlockFactory;
use customiesdevs\customies\block\Material;
use customiesdevs\customies\block\Model;
use customiesdevs\customies\item\CreativeInventoryInfo;
use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockIdentifier;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\BlockTypeInfo;
use pocketmine\math\Vector3;
use zhmurkov\block\RotatableBlock;

class RegisterZabors
{
    public static function load()
    {
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "zabor_dacha_1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:zabor_dacha_1",
            new Model([new Material(Material::TARGET_ALL, "zabor_dacha_1", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.zabor_dacha_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "zabor_dacha_2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:zabor_dacha_2",
            new Model([new Material(Material::TARGET_ALL, "zabor_dacha_2", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.zabor_dacha_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "zabor_dacha_3", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:zabor_dacha_3",
            new Model([new Material(Material::TARGET_ALL, "zabor_dacha_3", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.zabor_dacha_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "zabor_dacha_4", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:zabor_dacha_4",
            new Model([new Material(Material::TARGET_ALL, "zabor_dacha_4", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.zabor_dacha_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "zabor_dacha_4_2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:zabor_dacha_4_2",
            new Model([new Material(Material::TARGET_ALL, "zabor_dacha_4_2", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.zabor_dacha_4_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "zabor_dacha_4_1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:zabor_dacha_4_1",
            new Model([new Material(Material::TARGET_ALL, "zabor_dacha_4_1", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.zabor_dacha_4_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "zabor_dacha_3_1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:zabor_dacha_3_1",
            new Model([new Material(Material::TARGET_ALL, "zabor_dacha_3_1", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.zabor_dacha_3_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "zabor_dacha_3_2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:zabor_dacha_3_2",
            new Model([new Material(Material::TARGET_ALL, "zabor_dacha_3_2", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.zabor_dacha_3_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "zabor_voen_1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:zabor_voen_1",
            new Model([new Material(Material::TARGET_ALL, "zabor_voen_1", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.zabor_voen_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "zabor_voen_2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:zabor_voen_2",
            new Model([new Material(Material::TARGET_ALL, "zabor_voen_2", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.zabor_voen_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "zabor_voen_3", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:zabor_voen_3",
            new Model([new Material(Material::TARGET_ALL, "zabor_voen_3", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.zabor_voen_3", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "zabor_voen_4", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:zabor_voen_4",
            new Model([new Material(Material::TARGET_ALL, "zabor_voen_4", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.zabor_voen_4", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "zabor_voen_5", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:zabor_voen_5",
            new Model([new Material(Material::TARGET_ALL, "zabor_voen_5", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.zabor_voen_5", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "zabor_voen_6", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:zabor_voen_6",
            new Model([new Material(Material::TARGET_ALL, "zabor_voen_6", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.zabor_voen_6", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "zabor_sad", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:zabor_sad",
            new Model([new Material(Material::TARGET_ALL, "zabor_sad", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.zabor_sad", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "zabor_sad_2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:zabor_sad_2",
            new Model([new Material(Material::TARGET_ALL, "zabor_sad_2", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.zabor_sad", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "zabor_sad_3", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:zabor_sad_3",
            new Model([new Material(Material::TARGET_ALL, "zabor_sad_3", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.zabor_sad", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "zabor_sad_4", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:zabor_sad_4",
            new Model([new Material(Material::TARGET_ALL, "zabor_sad_4", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.zabor_sad", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
    }
}