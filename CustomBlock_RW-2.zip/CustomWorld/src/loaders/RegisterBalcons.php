<?php

namespace zhmurkov\loaders;

use customiesdevs\customies\block\CustomiesBlockFactory;
use customiesdevs\customies\block\Material;
use customiesdevs\customies\block\Model;
use customiesdevs\customies\item\CreativeInventoryInfo;
use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockIdentifier;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\BlockTypeInfo;
use pocketmine\math\Vector3;
use zhmurkov\block\RotatableBlock;

class RegisterBalcons
{
    public static function load()
    {
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "balkon_1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:balkon_1",
            new Model([new Material(Material::TARGET_ALL, "balkon_1", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.balkon_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "balkon_2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:balkon_2",
            new Model([new Material(Material::TARGET_ALL, "balkon_2", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.balkon_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "balkon_3", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:balkon_3",
            new Model([new Material(Material::TARGET_ALL, "balkon_3", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.balkon_3", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "balkon_pol", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:balkon_pol",
            new Model([new Material(Material::TARGET_ALL, "balkon_pol", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.balkon_pol", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "balkon_center", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:balkon_center",
            new Model([new Material(Material::TARGET_ALL, "balkon_center", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.balkon_center", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "balkon_ugol_1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:balkon_ugol_1",
            new Model([new Material(Material::TARGET_ALL, "balkon_ugol_1", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.balkon_ugol_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "balkon_ugol_2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:balkon_ugol_2",
            new Model([new Material(Material::TARGET_ALL, "balkon_ugol_2", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.balkon_ugol_2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "balkon_center_green", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:balkon_center_green",
            new Model([new Material(Material::TARGET_ALL, "balkon_center_green", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.balkon_center_green", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "balkon_ugol_1_green", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:balkon_ugol_1_green",
            new Model([new Material(Material::TARGET_ALL, "balkon_ugol_1_green", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.balkon_ugol_1_green", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "balkon_ugol_2_green", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:balkon_ugol_2_green",
            new Model([new Material(Material::TARGET_ALL, "balkon_ugol_2_green", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.balkon_ugol_2_green", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "balkon_center_brown", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:balkon_center_brown",
            new Model([new Material(Material::TARGET_ALL, "balkon_center_brown", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.balkon_center_brown", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "balkon_ugol_1_brown", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:balkon_ugol_1_brown",
            new Model([new Material(Material::TARGET_ALL, "balkon_ugol_1_brown", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.balkon_ugol_1_brown", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "balkon_ugol_2_brown", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:balkon_ugol_2_brown",
            new Model([new Material(Material::TARGET_ALL, "balkon_ugol_2_brown", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.balkon_ugol_2_brown", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "balkon_center_sand", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:balkon_center_sand",
            new Model([new Material(Material::TARGET_ALL, "balkon_center_sand", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.balkon_center_sand", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "balkon_ugol_1_sand", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:balkon_ugol_1_sand",
            new Model([new Material(Material::TARGET_ALL, "balkon_ugol_1_sand", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.balkon_ugol_1_sand", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "balkon_ugol_2_sand", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:balkon_ugol_2_sand",
            new Model([new Material(Material::TARGET_ALL, "balkon_ugol_2_sand", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.balkon_ugol_2_sand", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "balkon_center_red", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:balkon_center_red",
            new Model([new Material(Material::TARGET_ALL, "balkon_center_red", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.balkon_center_red", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "balkon_ugol_1_red", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:balkon_ugol_1_red",
            new Model([new Material(Material::TARGET_ALL, "balkon_ugol_1_red", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.balkon_ugol_1_red", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "balkon_ugol_2_red", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:balkon_ugol_2_red",
            new Model([new Material(Material::TARGET_ALL, "balkon_ugol_2_red", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.balkon_ugol_2_red", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "balkon_center_blue", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:balkon_center_blue",
            new Model([new Material(Material::TARGET_ALL, "balkon_center_blue", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.balkon_center_blue", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "balkon_ugol_1_blue", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:balkon_ugol_1_blue",
            new Model([new Material(Material::TARGET_ALL, "balkon_ugol_1_blue", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.balkon_ugol_1_blue", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "balkon_ugol_2_blue", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:balkon_ugol_2_blue",
            new Model([new Material(Material::TARGET_ALL, "balkon_ugol_2_blue", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.balkon_ugol_2_blue", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
    }
}