<?php

namespace zhmurkov\loaders;

use customiesdevs\customies\block\CustomiesBlockFactory;
use customiesdevs\customies\block\Material;
use customiesdevs\customies\block\Model;
use customiesdevs\customies\item\CreativeInventoryInfo;
use pocketmine\block\Block;
use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockIdentifier;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\BlockTypeInfo;
use pocketmine\math\Vector3;
use zhmurkov\block\RotatableBlock;

class RegisterWallsAndOther
{
    public static function load()
    {
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "bluewall", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:bluewall",
            new Model([new Material(Material::TARGET_ALL, "bluewall", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "greenglass", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:greenglass",
            new Model([new Material(Material::TARGET_ALL, "greenglass", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "linoleum1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:linoleum1",
            new Model([new Material(Material::TARGET_ALL, "linoleum1", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "linoleum2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:linoleum2",
            new Model([new Material(Material::TARGET_ALL, "linoleum2", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "linoleum3", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:linoleum3",
            new Model([new Material(Material::TARGET_ALL, "linoleum3", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "mosaic", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:mosaic",
            new Model([new Material(Material::TARGET_ALL, "mosaic", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallpaper1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallpaper1",
            new Model([new Material(Material::TARGET_ALL, "wallpaper1", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "whitewall", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:whitewall",
            new Model([new Material(Material::TARGET_ALL, "whitewall", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "whitewall1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:whitewall1",
            new Model([new Material(Material::TARGET_ALL, "whitewall1", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "whitewall2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:whitewall2",
            new Model([new Material(Material::TARGET_ALL, "whitewall2", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "whitewall3", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:whitewall3",
            new Model([new Material(Material::TARGET_ALL, "whitewall3", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "whitewall4", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:whitewall4",
            new Model([new Material(Material::TARGET_ALL, "whitewall4", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "whitewall5", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:whitewall5",
            new Model([new Material(Material::TARGET_ALL, "whitewall5", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "whitewall6", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:whitewall6",
            new Model([new Material(Material::TARGET_ALL, "whitewall6", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallpaper2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallpaper2",
            new Model([new Material(Material::TARGET_ALL, "wallpaper2", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallpaper3", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallpaper3",
            new Model([new Material(Material::TARGET_ALL, "wallpaper3", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallpaper4", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallpaper4",
            new Model([new Material(Material::TARGET_ALL, "wallpaper4", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallpaper5", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallpaper5",
            new Model([new Material(Material::TARGET_ALL, "wallpaper5", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallpaper6", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallpaper6",
            new Model([new Material(Material::TARGET_ALL, "wallpaper6", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallpaper7", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallpaper7",
            new Model([new Material(Material::TARGET_ALL, "wallpaper7", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallpaper8", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallpaper8",
            new Model([new Material(Material::TARGET_ALL, "wallpaper8", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallpaper9", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallpaper9",
            new Model([new Material(Material::TARGET_ALL, "wallpaper9", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallpaper10", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallpaper10",
            new Model([new Material(Material::TARGET_ALL, "wallpaper10", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallpaper11", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallpaper11",
            new Model([new Material(Material::TARGET_ALL, "wallpaper11", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallpaper12", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallpaper12",
            new Model([new Material(Material::TARGET_ALL, "wallpaper12", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallpaper13", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallpaper13",
            new Model([new Material(Material::TARGET_ALL, "wallpaper13", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallwood1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallwood1",
            new Model([new Material(Material::TARGET_ALL, "wallwood1", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallwood2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallwood2",
            new Model([new Material(Material::TARGET_ALL, "wallwood2", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "wallwood3", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:wallwood3",
            new Model([new Material(Material::TARGET_ALL, "wallwood3", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "blueskos1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:blueskos1",
            new Model([new Material(Material::TARGET_ALL, "blueskos1", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "blueskos2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:blueskos2",
            new Model([new Material(Material::TARGET_ALL, "blueskos2", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "blueskos3", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:blueskos3",
            new Model([new Material(Material::TARGET_ALL, "blueskos3", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "blueskos4", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:blueskos4",
            new Model([new Material(Material::TARGET_ALL, "blueskos4", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "blueskos5", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:blueskos5",
            new Model([new Material(Material::TARGET_ALL, "blueskos5", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "blueskos6", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:blueskos6",
            new Model([new Material(Material::TARGET_ALL, "blueskos6", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "blueskos7", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:blueskos7",
            new Model([new Material(Material::TARGET_ALL, "blueskos7", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "blueskos8", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:blueskos8",
            new Model([new Material(Material::TARGET_ALL, "blueskos8", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "blueskos9", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:blueskos9",
            new Model([new Material(Material::TARGET_ALL, "blueskos9", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "blueskos10", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:blueskos10",
            new Model([new Material(Material::TARGET_ALL, "blueskos10", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "blueskos11", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:blueskos11",
            new Model([new Material(Material::TARGET_ALL, "blueskos11", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "blueskos12", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:blueskos12",
            new Model([new Material(Material::TARGET_ALL, "blueskos12", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "greenskos1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:greenskos1",
            new Model([new Material(Material::TARGET_ALL, "greenskos1", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "greenskos2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:greenskos2",
            new Model([new Material(Material::TARGET_ALL, "greenskos2", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "greenskos3", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:greenskos3",
            new Model([new Material(Material::TARGET_ALL, "greenskos3", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "greenskos4", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:greenskos4",
            new Model([new Material(Material::TARGET_ALL, "greenskos4", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "greenskos5", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:greenskos5",
            new Model([new Material(Material::TARGET_ALL, "greenskos5", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "greenskos6", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:greenskos6",
            new Model([new Material(Material::TARGET_ALL, "greenskos6", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "greenskos7", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:greenskos7",
            new Model([new Material(Material::TARGET_ALL, "greenskos7", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "greenskos8", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:greenskos8",
            new Model([new Material(Material::TARGET_ALL, "greenskos8", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "greenskos9", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:greenskos9",
            new Model([new Material(Material::TARGET_ALL, "greenskos9", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "greenskos10", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:greenskos10",
            new Model([new Material(Material::TARGET_ALL, "greenskos10", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "greenskos11", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:greenskos11",
            new Model([new Material(Material::TARGET_ALL, "greenskos11", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "greenskos12", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:greenskos12",
            new Model([new Material(Material::TARGET_ALL, "greenskos12", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new Block(new BlockIdentifier($id), "shtukaturka", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:shtukaturka",
            new Model([new Material(Material::TARGET_ALL, "shtukaturka", Material::RENDER_METHOD_OPAQUE)]),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
    }
}