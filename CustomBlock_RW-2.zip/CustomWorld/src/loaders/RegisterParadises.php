<?php

namespace zhmurkov\loaders;

use customiesdevs\customies\block\CustomiesBlockFactory;
use customiesdevs\customies\block\Material;
use customiesdevs\customies\block\Model;
use customiesdevs\customies\item\CreativeInventoryInfo;
use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockIdentifier;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\BlockTypeInfo;
use pocketmine\math\Vector3;
use zhmurkov\block\RotatableBlock;

class RegisterParadises
{
    public static function load()
    {
        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise1",
            new Model([new Material(Material::TARGET_ALL, "paradise1", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise2", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise2",
            new Model([new Material(Material::TARGET_ALL, "paradise2", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise2", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise3", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise3",
            new Model([new Material(Material::TARGET_ALL, "paradise3", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise3", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise4", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise4",
            new Model([new Material(Material::TARGET_ALL, "paradise4", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise4", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise5", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise5",
            new Model([new Material(Material::TARGET_ALL, "paradise5", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise5", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise6", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise6",
            new Model([new Material(Material::TARGET_ALL, "paradise6", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise6", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise7", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise7",
            new Model([new Material(Material::TARGET_ALL, "paradise7", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise7", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise8", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise8",
            new Model([new Material(Material::TARGET_ALL, "paradise8", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise8", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise9", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise9",
            new Model([new Material(Material::TARGET_ALL, "paradise9", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise9", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise10", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise10",
            new Model([new Material(Material::TARGET_ALL, "paradise10", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise10", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise11", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise11",
            new Model([new Material(Material::TARGET_ALL, "paradise11", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise11", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise13", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise13",
            new Model([new Material(Material::TARGET_ALL, "paradise13", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise13", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise14", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise14",
            new Model([new Material(Material::TARGET_ALL, "paradise14", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise14", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise15", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise15",
            new Model([new Material(Material::TARGET_ALL, "paradise15", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise15", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise16", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise16",
            new Model([new Material(Material::TARGET_ALL, "paradise16", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise16", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise17", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise17",
            new Model([new Material(Material::TARGET_ALL, "paradise17", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise17", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise18", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise18",
            new Model([new Material(Material::TARGET_ALL, "paradise18", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise18", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise19", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise19",
            new Model([new Material(Material::TARGET_ALL, "paradise19", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise19", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise20", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise20",
            new Model([new Material(Material::TARGET_ALL, "paradise20", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise20", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise21", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise21",
            new Model([new Material(Material::TARGET_ALL, "paradise21", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise21", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise22", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise22",
            new Model([new Material(Material::TARGET_ALL, "paradise22", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise22", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise23", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise23",
            new Model([new Material(Material::TARGET_ALL, "paradise23", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise23", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise24", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise24",
            new Model([new Material(Material::TARGET_ALL, "paradise24", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise24", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise25", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise25",
            new Model([new Material(Material::TARGET_ALL, "paradise25", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise25", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise26", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise26",
            new Model([new Material(Material::TARGET_ALL, "paradise26", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise26", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise27", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise27",
            new Model([new Material(Material::TARGET_ALL, "paradise27", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise27", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise28", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise28",
            new Model([new Material(Material::TARGET_ALL, "paradise28", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise28", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise29", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise29",
            new Model([new Material(Material::TARGET_ALL, "paradise29", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise29", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise30", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise30",
            new Model([new Material(Material::TARGET_ALL, "paradise30", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise30", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise31", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise31",
            new Model([new Material(Material::TARGET_ALL, "paradise31", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise31", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise32", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise32",
            new Model([new Material(Material::TARGET_ALL, "paradise32", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise32", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise33", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise33",
            new Model([new Material(Material::TARGET_ALL, "paradise33", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise33", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise34", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise34",
            new Model([new Material(Material::TARGET_ALL, "paradise34", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise34", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise35", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise35",
            new Model([new Material(Material::TARGET_ALL, "paradise35", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise35", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise36", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise36",
            new Model([new Material(Material::TARGET_ALL, "paradise36", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise36", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise37", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise37",
            new Model([new Material(Material::TARGET_ALL, "paradise37", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise37", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );

        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise38", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise38",
            new Model([new Material(Material::TARGET_ALL, "paradise38", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise38", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise41", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise41",
            new Model([new Material(Material::TARGET_ALL, "paradise41", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise41", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise42", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise42",
            new Model([new Material(Material::TARGET_ALL, "paradise42", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise42", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise43", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise43",
            new Model([new Material(Material::TARGET_ALL, "paradise43", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise43", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise44", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise44",
            new Model([new Material(Material::TARGET_ALL, "paradise44", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise44", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise45", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise45",
            new Model([new Material(Material::TARGET_ALL, "paradise45", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise45", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise46", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise46",
            new Model([new Material(Material::TARGET_ALL, "paradise46", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise46", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise47", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise47",
            new Model([new Material(Material::TARGET_ALL, "paradise47", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise47", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise48", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise48",
            new Model([new Material(Material::TARGET_ALL, "paradise48", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise48", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise49", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise49",
            new Model([new Material(Material::TARGET_ALL, "paradise49", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise49", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise50", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise50",
            new Model([new Material(Material::TARGET_ALL, "paradise50", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise50", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise51", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise51",
            new Model([new Material(Material::TARGET_ALL, "paradise51", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise51", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise52", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise52",
            new Model([new Material(Material::TARGET_ALL, "paradise52", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise52", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise53", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise53",
            new Model([new Material(Material::TARGET_ALL, "paradise53", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise53", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise54", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise54",
            new Model([new Material(Material::TARGET_ALL, "paradise54", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise54", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise55", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise55",
            new Model([new Material(Material::TARGET_ALL, "paradise55", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise55", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise56", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise56",
            new Model([new Material(Material::TARGET_ALL, "paradise56", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise56", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise57", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise57",
            new Model([new Material(Material::TARGET_ALL, "paradise57", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise57", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise58", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise58",
            new Model([new Material(Material::TARGET_ALL, "paradise58", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise58", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise59", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise59",
            new Model([new Material(Material::TARGET_ALL, "paradise59", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise59", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise60", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise60",
            new Model([new Material(Material::TARGET_ALL, "paradise60", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise60", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise61", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise61",
            new Model([new Material(Material::TARGET_ALL, "paradise61", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise61", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise62", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise62",
            new Model([new Material(Material::TARGET_ALL, "paradise62", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise62", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise63", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise63",
            new Model([new Material(Material::TARGET_ALL, "paradise63", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise63", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise64", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise64",
            new Model([new Material(Material::TARGET_ALL, "paradise64", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise64", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise65", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise65",
            new Model([new Material(Material::TARGET_ALL, "paradise65", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise65", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise66", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise66",
            new Model([new Material(Material::TARGET_ALL, "paradise66", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise66", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise67", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise67",
            new Model([new Material(Material::TARGET_ALL, "paradise67", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise67", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );


        $id = BlockTypeIds::newId();
        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new RotatableBlock(new BlockIdentifier($id), "paradise68", new BlockTypeInfo(new BlockBreakInfo(0.3))),
            "rwpe:paradise68",
            new Model([new Material(Material::TARGET_ALL, "paradise68", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.paradise67", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
            new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
        );
    }
}