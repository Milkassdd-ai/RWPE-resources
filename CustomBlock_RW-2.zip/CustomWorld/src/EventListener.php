<?php

declare(strict_types=1);

namespace zhmurkov;

use pocketmine\event\block\LeavesDecayEvent;

class EventListener implements \pocketmine\event\Listener{

	public function __construct(){}

    public function onLeavesDecay(LeavesDecayEvent $event): void
    {
        $event->cancel();
    }
}