<?php
declare(strict_types=1);

namespace zhmurkov;

use customiesdevs\customies\block\{CustomiesBlockFactory, Material, Model};
use customiesdevs\customies\item\CreativeInventoryInfo;
use pocketmine\block\{Block, BlockBreakInfo, BlockIdentifier, BlockTypeIds, BlockTypeInfo};
use pocketmine\math\Vector3;
use pocketmine\plugin\PluginBase;
use zhmurkov\block\RotatableBlock;
use zhmurkov\loaders\RegisterBalcons;
use zhmurkov\loaders\RegisterGarders;
use zhmurkov\loaders\RegisterPanels;
use zhmurkov\loaders\RegisterParadises;
use zhmurkov\loaders\RegisterRail;
use zhmurkov\loaders\RegisterStolbs;
use zhmurkov\loaders\RegisterTrubs;
use zhmurkov\loaders\RegisterUtils;
use zhmurkov\loaders\RegisterWallbricks;
use zhmurkov\loaders\RegisterWallsAndOther;
use zhmurkov\loaders\RegisterWindows;
use zhmurkov\loaders\RegisterZabors;

class Main extends PluginBase{

	protected function onEnable() : void{
		$this->getServer()->getPluginManager()->registerEvents(new EventListener(), $this);

        RegisterParadises::load();
        RegisterWallbricks::load();
        RegisterPanels::load();
        RegisterWindows::load();
        RegisterRail::load();
        RegisterBalcons::load();
        RegisterStolbs::load();
        RegisterZabors::load();
        RegisterTrubs::load();
        RegisterWallsAndOther::load();
        RegisterUtils::load();
        RegisterGarders::load();

		$id = BlockTypeIds::newId();
		CustomiesBlockFactory::getInstance()->registerBlock(
			static fn() => new RotatableBlock(new BlockIdentifier($id), "Provoda1", new BlockTypeInfo(new BlockBreakInfo(0.3))),
			"rwpe:provoda_1",
			new Model([new Material(Material::TARGET_ALL, "provoda_1", Material::RENDER_METHOD_ALPHA_TEST)], "geometry.provoda_1", new Vector3(-8, 0, -8), new Vector3(16, 16, 4)),
			new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE)
		);
	}
}
