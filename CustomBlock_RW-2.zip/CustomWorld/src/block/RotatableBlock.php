<?php
declare(strict_types=1);

namespace zhmurkov\block;

use customiesdevs\customies\block\permutations\RotatableTrait;

class RotatableBlock extends \pocketmine\block\Transparent implements \customiesdevs\customies\block\permutations\Permutable{
	use RotatableTrait;
}
